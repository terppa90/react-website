import React from 'react';
import '../../App.css';

export default function Products() {
  return <h1 className="products">PRODUCTS</h1>;
}
